<?php
/**
 *      @author El Boletaire <elboletaire at underave dot net>
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 3 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */
class UploadifyHelper extends AppHelper
{
	var $helpers = array('Javascript','Html');
	
	var $css = 'uploadify';
	var $uploader = '/js/uploadify/uploader.swf';
	var $script = 'upload';
	var $cancelImg = '/js/uploadify/cancel.png';
	var $auto = false;
	var $multi = false;
	var $sizelimit = 314572800; // 300MB en bytes
	
	var $options = array('uploader','script','checkScript','scriptData','fileDataName','scriptAccess',
		'buttonText','buttonImg','hideButton','rollover','width','height','wmode','onInit','onSelect',
		'onSelectOnce','onCancel','onClearQueue','onError','onProgress','onComplete','onAllComplete',
		'onCheck','cancelImg','auto','fileExt','fileDesc','multi','sizeLimit','simUploadLimit');
	
	/** Inicia les variables especificades mitjançant $options */
	private function __processOptions($folder,&$options)
	{
		foreach($folder as $id=>$fol)
		{
			foreach ($this->options as $val)
			{
				// Si la variable és buida i no està iniciada al helper, indiquem que el seu valor és el del helper 
				if(empty($options[$id][$val]) && !empty($this->$val)) $options[$id][$val] = $this->$val;
			}
		}
	}
	
	/** Genera les capçaleres necessàries per a iniciar uploadify */
	private function __init($jquery = true, $uploadify = true, $css = true)
	{
		$ret = '';
		if($css) $ret .= $this->Html->css($this->css,null,null,false);
		if($jquery) $ret .= $this->Javascript->link('jquery-1.3.2.min',false);
		if($uploadify) $ret .= $this->Javascript->link('uploadify/jquery.uploadify',false);
		return $ret;
	}
	
	public function startUploader($folder,$options = null, $init = true)
	{
		// Iniciem variables i altres fitxers
		$code = '';
		$uploadify = '';
		if ($init) $code .= $this->__init();
		$this->__processOptions($folder,$options);
		// Javascript d'uploadify
		$uploadify .= "$(document).ready(function() {\n";
		foreach($folder as $key=>$val)
		{
			// Configuració per a cada botó que necessitem
			$options[$key]['uploader'] = $this->url($options[$key]['uploader']);
			$options[$key]['cancelImg'] = $this->url($options[$key]['cancelImg']);
			$uploadify .= "\t$('#" . $key . "').fileUpload ({\n";
			foreach($this->options as $option)
			{
				// Si la variable existeix
				if(!empty($options[$key][$option])){
					// Afegim la línia de configuració
					if(!ereg("[{}]", $options[$key][$option]))
						$uploadify .= "\t\t'$option' : '".$options[$key][$option] . "',\n";
					else $uploadify .= "\t\t'$option' : ".$options[$key][$option] . ",\n";
				}
			}
			// Tanquem configuració
			$uploadify .= "\t\t'folder': '".$val."'\n\t});\n";
		}
		$uploadify .= "});\n";
		// Inserim el codi entre etiquetes script
		$code .= $this->Javascript->codeBlock($uploadify,array('inline'=>false));
		return $code;
	}
}